// const reviewModel = require('../models/reviewModel');
// const booksModel = require('../models/bookModel');
// const mongoose = require("mongoose")

// //✅validation........................................................

// const isValidRequestBody = function (requestBody) {
//     return Object.entries((requestBody).length > 0)
// }

// const isValid = function (value) {
//     if (typeof value == undefined || value == null) return false
//     if (typeof value === 'string' && value.trim().length === 0) return false
//     return true
// }
// const isValidObjectId = function(objectId) {
//     return mongoose.Types.ObjectId.isValid(objectId)
// }


// //✅Creat Review.......................................................
// const creatReview = async function (req, res) {
//     try {
//         const params = req.params.bookId //accessing bookId from params.
//         requestReviewBody = req.body
//         const { reviewedBy, rating, review } = requestReviewBody;

//         //validation starts.
//         if (!isValidObjectId(params)) {
//             return res.status(400).send({ status: false, message: "Invalid bookId." })
//         }

//         //for empty request body.
//         if (!isValidRequestBody(requestReviewBody)) {
//             return res.status(400).send({ status: false, message: 'Invalid request parameters. Please provide review details to update.' })
//         }
//         if (!isNaN(reviewedBy)) {
//             return res.status(400).send({ status: false, message: "Reviewer's name cannot be a number." })
//         }

//         if (!isValid(reviewedBy)) {
//             return res.status(400).send({ status: false, message: "Reviewer's name is required" })
//         }
//         if (!isValid(rating)) {
//             return res.status(400).send({ status: false, message: "Rating is required" })
//         }
//         if (!isValid(rating)) {
//             return res.status(400).send({ status: false, message: "Rating must be 1,2,3,4 or 5." })
//         }
//         // if (!isValid(review)) {
//         //     return res.status(400).send({ status: false, message: "No comments on this book yet" })
//         // }
//         //validation ends.

//         //setting rating limit between 1-5.
//         if (!(rating >= 1 && rating <= 5)) {
//             return res.status(400).send({ status: false, message: "Rating must be in between 1 to 5." })
//         }
//         const searchBook = await booksModel.findById({ _id: params})
//         console.log(searchBook)
//         if (!searchBook) {
//             return res.status(404).send({ status: false, message: `Book does not exist by this ${params}.` })
//         }

//         //verifying the book is deleted or not so that we can add a review to it.
//         if (searchBook.isDeleted == true) {
//             return res.status(400).send({ status: false, message: "Cannot add review, Book has been already deleted." })
//         }
//         requestReviewBody.bookId = searchBook._id;
//         requestReviewBody.reviewedAt = new Date();

//         const saveReview = await reviewModel.create(requestReviewBody)
//         if (saveReview) {
//             await booksModel.findOneAndUpdate({ _id: params }, { $inc: { reviews: 1 } })
//         }
//         const response = await reviewModel.findOne({ id: saveReview._id }).select({_v: 0, createdAt: 0, updatedAt: 0, isDeleted: 0 })
//         return res.status(201).send({ status: true, message: `Review added successfully for ${searchBook.title}`, data: response })
//     } catch (err) {
//         return res.status(500).send({ status: false, Error: err.message })
//     }
// }

// //................................put_api_update_review......................................\\

// const updatebyReviewId = async function (req, res) {
//     try {
//         const bookParams = req.params.bookId;
//         const reviewParams = req.params.reviewId
//         const requestUpdateBody = req.body
//         const { review, rating, reviewedBy } = requestUpdateBody;

//         //validation starts.
//         if (!isValidObjectId(bookParams)) {
//             return res.status(400).send({ status: false, message: "Invalid bookId." })
//         }
//         if (!isValidObjectId(reviewParams)) {
//             return res.status(400).send({ status: false, message: "Invalid reviewId." })
//         }
//         if (!isValidRequestBody(requestUpdateBody)) {
//             return res.status(400).send({ status: false, message: 'Invalid request parameters. Please provide review details to update.' })
//         } //validation ends

//         //setting combinations
//         if (review || rating || reviewedBy) {

//             if (!isValid(review)) {
//                 return res.status(400).send({ status: false, message: "Review is missing ! Please provide the review details to update." })
//             }
//             if (!isValid(reviewedBy)) {
//                 return res.status(400).send({ status: false, message: "Reviewer's name is missing ! Please provide the name to update." })
//             };
//         }

//         //finding book and review on which we have to update.
//         const searchBook = await booksModel.findById({ _id: bookParams }).select({ createdAt: 0, updatedAt: 0, __v: 0 })
//         if (!searchBook) {
//             return res.status(404).send({ status: false, message: `Book does not exist by this ${bookParams}. ` })
//         }
//         const searchReview = await reviewModel.findById({ _id: reviewParams })
//         if (!searchReview) {
//             return res.status(404).send({status: false,message: `Review does not exist by this ${reviewParams}.`})
//         }

//         //checking whether the rating is number or character.
//         if (typeof (rating) === 'number') {
//             if (req.body.rating === 0) {
//                 return res.status(400).send({ status: false, message: "Rating cannot be 0. Please provide rating between 1 to 5." })
//             }
//             if (!isValid(rating)) {
//                 return res.status(400).send({ status: false, message: "Rating must be 1,2,3,4 or 5." })
//             }
//             if (!(rating > 0 && rating < 6)) {
//                 return res.status(400).send({ status: false, message: "Rating must be in between 1 to 5." })
//             }
//         }

//         //verifying the attribute isDeleted:false or not for both books and reviews documents.
//         if (searchBook.isDeleted == false) {
//             if (searchReview.isDeleted == false) {
//                 const updateReviewDetails = await reviewModel.findOneAndUpdate({ _id: reviewParams }, { review: review, rating: rating, reviewedBy: reviewedBy }, { new: true })

//                 let destructureForResponse = searchBook.toObject();
//                 destructureForResponse['updatedReview'] = updateReviewDetails;

//                 return res.status(200).send({ status: true, message: "Successfully updated the review of the book.", data: destructureForResponse })

//             } else {
//                 return res.status(400).send({ status: false, message: "Unable to update details.Review has been already deleted" })
//             }
//         } else {
//             return res.status(400).send({ status: false, message: "Unable to update details.Book has been already deleted" })
//         }
//     } catch (err) {
//         return res.status(500).send({ status: false, Error: err.message })
//     }
// }



// //DELETE REVIEW
// const deleteByReviewId = async function (req, res) {
//     try {
//         const bookParams = req.params.bookId;
//         const reviewParams = req.params.reviewId

//         //validation starts.
//         if (!isValidObjectId(bookParams)) {
//             return res.status(400).send({ status: false, message: "Invalid bookId." })
//         }
//         if (!isValidObjectId(reviewParams)) {
//             return res.status(400).send({ status: false, message: "Invalid reviewId." })
//         }
//         //validation ends.

//         //finding book and checking whether it is deleted or not.
//         const searchBook = await booksModel.findById({ _id: bookParams, isDeleted: false })
//         if (!searchBook) {
//             return res.status(400).send({ status: false, message: `Book does not exist by this ${bookParams}.` })
//         }

//         //finding review and checking whether it is deleted or not.
//         const searchReview = await reviewModel.findById({ _id: reviewParams })
//         if (!searchReview) {
//             return res.status(400).send({ status: false, message: `Review does not exist by this ${reviewParams}.` })
//         }

//         //verifying the attribute isDeleted:false or not for both books and reviews documents.
//         if (searchBook.isDeleted == false) {
//             if (searchReview.isDeleted == false) {
//                 const deleteReviewDetails = await reviewModel.findOneAndUpdate({ _id: reviewParams }, { isDeleted: true, deletedAt: new Date() }, { new: true })

//                 if (deleteReviewDetails) {
//                     await booksModel.findOneAndUpdate({ _id: bookParams },{$inc:{ reviews: -1 }})
//                 }
//                 return res.status(200).send({ status: true, message: "Review deleted successfully.", data:deleteReviewDetails})

//             } else {
//                 return res.status(400).send({ status: false, message: "Unable to delete review details.Review has been already deleted" })
//             }
//         } else {
//             return res.status(400).send({ status: false, message: "Unable to delete .Book has been already deleted" })
//         }
//     } catch (err) {
//         return res.status(500).send({ status: false, Error: err.message })
//     }
// }


// module.exports.creatReview = creatReview
// module.exports.updatebyReviewId = updatebyReviewId
// module.exports.deleteByReviewId = deleteByReviewId




const reviewModel = require('../models/reviewModel')
const bookModel = require('../models/bookModel')

const isValid = function(value) {
    if(typeof value === 'undefined' || value === null) return false
    if(typeof value === 'string' && value.trim().length === 0) return false
    return true;
}


const createReview = async function (req, res) {
    try {
        const reviewBody = req.body

        const bookId = req.params.bookId

        if(Object.keys(reviewBody) == 0) {
            return res.status(400).send({ status: false, message: 'Please provide review details' })
        }

        if (!(/^[0-9a-fA-F]{24}$/.test(bookId))) {
            return res.status(400).send({ status: false, message: 'please provide valid bookId' })
        }

        const book = await bookModel.findOne({_id:bookId,isDeleted:false})

        if (!book) {
            return res.status(404).send({ status: false, message: 'book not found' })
        }

        const { review, rating, reviewedBy, reviewedAt } = reviewBody

        if (!isValid(rating)) {
            return res.status(400).send({ status: false, message: 'rating is required' })
        }

        if (!isValid(reviewedAt)) {
            return res.status(400).send({ status: false, message: 'review date is required' })
        }

        if (!(/^((?:19|20)[0-9][0-9])-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])/.test(reviewedAt))) {
            return res.status(400).send({ status: false, message: 'please provide valid date in format (YYYY-MM-DD)' })
        }

        if (reviewBody.rating < 1 || reviewBody.rating > 5 ) {
            res.status(400).send({ status: false, message: 'please provide ratings ( 1 - 5 )' })
            return
        }

        const reviewData = { bookId, rating, review, reviewedBy, reviewedAt: Date.now() }

        const addReview = await reviewModel.create(reviewData)

        book.reviews = book.reviews + 1
        await book.save()

        const data = book.toObject()
        data.reviewsData = addReview

        return res.status(201).send({ status: true, message: 'Review added successsfully', data: data })


    }
    catch (error) {
        return res.status(500).send({ status: false, message: error.message })
    }
}


//Update

const updateReviews = async function (req, res) {
    let getBookId = req.params.bookId;
    let getReviewId = req.params.reviewId
    let data = req.body;

    if (!data) {
         return res.status(400).send({ status: false, message: "enter data for update" }) 
        }

    let checkBookId = await bookModel.findOne({ _id: getBookId }, { isDeleted: false })

    if (!checkBookId) { 
        return res.status(400).send({ status: false, message: "no book exist with this id" })
     }

    let checkReviewId = await reviewModel.findOne({ _id: getReviewId , isDeleted: false })

    if (!checkReviewId) { 
        return res.status(400).send({ status: false, message: "no review exist with this id" }) 
    }
    if (data.rating < 1 || data.rating > 5 ) {
        res.status(400).send({ status: false, message: 'please provide ratings ( 1 - 5 )' })
        return
    }


    let updateReview = await reviewModel.findOneAndUpdate({ _id: getReviewId, bookId: getBookId },
        { $set: { review: data.review, rating: data.rating, reviewedBy: data.reviewedBy,reviewedAt:Date.now() } }, { new: true })

    return res.status(200).send({ status: true, message: "review updated successfully", data: updateReview })
}





//*### DELETE 


const deleteReviewById = async function (req, res) {
    try {
        const bookId = req.params.bookId
        const reviewId = req.params.reviewId

        if (!(/^[0-9a-fA-F]{24}$/.test(bookId))) {
            return res.status(400).send({ status: false, message: 'please provide valid bookId' })
        }
        const book = await bookModel.findOne({ _id: bookId, isDeleted: false })
        if (!book) {
            res.status(400).send({ status: false, message: "Book doesn't exist" })
            return
        }
        if (!(/^[0-9a-fA-F]{24}$/.test(reviewId))) {
            res.status(400).send({ status: false, message: 'please provide valid reviewId' })
            return
        }
        const review = await reviewModel.findOne({ _id: reviewId, bookId: bookId, isDeleted: false })
        if (!review) {
            res.status(400).send({ status: false, message: "review doesn't exist for given bookId" })
            return
        }

    
        const deletedReview = await reviewModel.findOneAndUpdate({ _id: reviewId, bookId: bookId }, { isDeleted: true }, { new: true })

        
        const decreaseCount = await bookModel.findOneAndUpdate({ _id: bookId }, { $inc: { reviews: -1 } }) 
              res.status(200).send({ status: true, message: "review deleted successfully" })
    }
    catch (error) {
        console.log(error.message)
        res.status(500).send({ status: false, message: error.message })
    }
}



module.exports.createReview = createReview
module.exports.updateReviews = updateReviews
module.exports.deleteReviewById = deleteReviewById

