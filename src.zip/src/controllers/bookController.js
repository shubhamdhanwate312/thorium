// const booksModel = require("../models/bookModel");
// const userModel = require('../models/userModel');
// const reviewModel = require('../models/reviewModel');
// const ObjectId = require('mongoose').Types.ObjectId;


// const isValid = function (value) {
//   if (typeof value == undefined || value == null || value.length == 0) return false
//   if (typeof value === 'string' && value.trim().length === 0) return false
//   return true
// }
// const isValidRequestBody = function (requestBody) {
//   return Object.keys(requestBody).length > 0
// }


// //1️⃣Create book ...............................................

// const createBook = async function (req, res) {
//   try {
//       const bookBody = req.body
//       if(!isValidRequestBody(bookBody)) {
//           return res.status(400).send({status: false, message: 'Please provide book details'})
//       }

//       const { title, excerpt, userId, ISBN, category, subcategory, reviews, releasedAt } = bookBody

//       if(!isValid(title)) {
//           return res.status(400).send({status: false, message: 'title is required'})
//       }

//       const duplicateTitle = await booksModel.findOne({title: title})

//       if(duplicateTitle) {
//           return res.status(400).send({status: false, message: 'Title already exist'})
//       }

//       if(!isValid(excerpt)) {
//           return res.status(400).send({status: false, message: 'excerpt is required'})
//       }

//       if(!isValid(userId)) {
//           return res.status(400).send({status: false, message: 'userId is required'})
//       }

//       if(!isValid(ISBN)) {
//           return res.status(400).send({status: false, message: 'ISBN is required'})
//       }

//       const duplicateISBN = await booksModel.findOne({ISBN: ISBN})

//       if(duplicateISBN) {
//           return res.status(400).send({status: false, message: 'ISBN already exist'})
//       }

//       if(!isValid(category)) {
//           return res.status(400).send({status: false, message: 'category is required'})
//       }

//       if(!isValid(subcategory)) {
//           return res.status(400).send({status: false, message: 'subcategory is required'})
//       }


//       if(!isValid(releasedAt)) {
//           return res.status(400).send({status: false, message: 'releasedAt is required'})
//       }

//       if(!(/^((?:19|20)[0-9][0-9])-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])/.test(bookBody.releasedAt))) {
//           return res.status(400).send({ status: false, message: "Plz provide valid released Date" })
//         }
      
//       const userPresent = await userModel.findById(userId)

//       if(!userPresent) {
//           return res.status(400).send({status: false, message: `userId ${userId} is not present`})
//       }

//       const reqData = { title, excerpt, userId, ISBN, category, subcategory, reviews, releasedAt }

//       const bookCreated = await booksModel.create(reqData)
//       return res.status(201).send({status: true, message: 'Book Successfully Created', data: bookCreated})

//   }
//   catch(error) {
//       return res.status(500).send({status: false, error: error.message})
//   }
// }


// //2️⃣ GET BOOKS ........

// const getbook = async function (req, res) {
//   try {
//     const data = req.query
//     const filter = {
//       ...data,
//       isDeleted: false
//     }
//     const Books = await booksModel.find(filter).select({
//       title: 1, excerpt: 1, userId: 1, category: 1,
//       releasedAt: 1, reviews: 1
//     }).sort({ title: 1 })

//     if (Books.length === 0) {
//       return res.status(404).send({ status: false, message: "no books found." })
//     }

//     res.status(200).send({ status: true, message: "books list", data: Books })
//   }

//   catch (err) {
//     return res.status(500).send({ status: false, ERROR: err.message })

//   }
// }


// //3️⃣GET BOOKS BY ID  .................................

// let getbookdetailsById = async function (req, res) {
//   try {
//     let bookId = req.params.bookId

//     if (!isValid(bookId.trim())) {
//         return res.status(400).send({ status: false, msg: "bookId required" })

//     }
//     let reviewList = await booksModel.findOne({ bookId: bookId })
//     if (!reviewList) {
//         return res.status(404).send({ status: false, msg: "not found " })
//     }
//     if (!ObjectId.isValid(bookId)) {
//         return res.status(400).send({ status: false, msg: "bookId invalid" })
//     }
//     let result = {
//         _id: reviewList._id,
//         title: reviewList.title,
//         excerpt: reviewList.excerpt,
//         userId: reviewList.userId,
//         category: reviewList.category,
//         subcategory: reviewList.subcategory,
//         deleted: reviewList.isDeleted,
//         reviews: reviewList.reviews,
//         deletedAt: reviewList.deletedAt,
//         releasedAt: reviewList.releasedAt,
//         createdAt: reviewList.createdAt,
//         updatedAt: reviewList.updatedAt
//     }
//     let eachReview = await reviewModel.find({ bookId: bookId }).select({ bookId: 1, reviewedBy: 1, reviewedAt: 1, rating: 1, review: 1 })
//     if (!eachReview) {
//         result['reviewsData'] = "No review for this books"
//         return res.status(200).send({ status: false, data: result })
//     }
//     result['reviewsData'] = eachReview
//     return res.status(200).send({ status: false, data: result })



// }
// catch (err) {
//     return res.status(500).send({ status: false, msg: err.message })
// }


// }



// //4️⃣ DELETE BOOK BY ID ........

// let deleteById = async function (req, res) {

//   try {

//     const bookId = req.params.bookId

//     if (!bookId) {
//       return res.status(400).send({ status: false, message: "bookId is required in path params" })
//     }

//     if (!isValid(bookId)) {
//       return res.status(400).send({ status: false, message: `enter a valid bookId` })
//     }

//     const bookById = await booksModel.findOne({ _id: bookId, isDeleted: false, deletedAt: null })

//     if (!bookById) {
//       return res.status(404).send({ status: false, message: "no book found by this ID" })
//     }

//     const deleteBooks = await booksModel.findByIdAndUpdate(bookId, { $set: { isDeleted: true, deletedAt: Date.now() } }, { new: true })

//     res.status(200).send({ status: true, message: "book deleted successfully" })


//   } catch (err) {
//     res.status(500).send({ error: err.message })
//   }
// }




// //5️⃣UPDATE BOOK

// const updateBook = async function (req, res) {
//   try {
//     const bookId = req.params.bookId
//     const dataForUpdation = req.body

//     if (!(/^[0-9a-fA-F]{24}$/.test(bookId))) {
//       return res.status(400).send({ status: false, message: 'please provide valid bookId' })
//     }

//     const book = await booksModel.findOne({ _id: bookId, isDeleted: false })

//     if (!book) {
//       return res.status(404).send({ status: false, message: "No data found" })
//     }

//     if (!isValidRequestBody(dataForUpdation)) {
//       return res.status(400).send({ status: false, message: 'please provide data for updation' })
//     }

//     const { title, excerpt, ISBN, releasedAt } = dataForUpdation

//     if (!isValid(title)) {
//       return res.status(400).send({ status: false, message: 'please provide title' })

//     }

//     const duplicateTitle = await booksModel.findOne({ title: title })
//     if (duplicateTitle) {
//       return res.status(400).send({ status: false, message: "This title already in use ,please provide another one" })
//     }

//     if (!isValid(excerpt)) {
//       return res.status(400).send({ status: false, message: 'please provide excerpt' })
//     }

//     if (!isValid(ISBN)) {
//       return res.status(400).send({ status: false, message: 'please provide ISBN' })
//     }

//     if (!(/^\+?([1-9]{3})\)?[-. ]?([0-9]{10})$/.test(ISBN))) {
//       return res.status(400).send({ status: false, message: 'please provide valid ISBN' })
//     }

//     const duplicateISBN = await booksModel.findOne({ ISBN: ISBN })
//     if (duplicateISBN) {
//       return res.status(400).send({ status: false, message: "This ISBN already in use ,please provide another one" })
//     }

//     if (!isValid(releasedAt)) {
//       return res.status(400).send({ status: false, message: 'please provide releasedAt' })
//     }

//     if (!(/^((?:19|20)[0-9][0-9])-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])/.test(releasedAt))) {
//       return res.status(400).send({ status: false, message: 'please provide valid date in format (YYYY-MM-DD)' })
//     }

//     const updateData = { title, excerpt, ISBN, releasedAt }

//     const updatedBook = await booksModel.findOneAndUpdate({ _id: bookId }, { ...updateData }, { new: true })

//     return res.status(200).send({ status: true, message: "Book updated successfully", data: updatedBook })
//   }
//   catch (err) {
//     console.log(err)
//     res.status(500).send({ status: false, message: err.message })
//   }
// }



// module.exports.createBook = createBook
// module.exports.getbook = getbook;
// module.exports.updateBook = updateBook;
// module.exports.deleteById = deleteById;
// module.exports.getbookdetailsById = getbookdetailsById














const bookModel = require('../models/bookModel')
const userModel = require('../models/userModel')
const reviewModel = require('../models/reviewModel')
const moment = require("moment")

const isValid = function(value) {
    if(typeof value === 'undefined' || value === null) return false
    if(typeof value === 'string' && value.trim().length === 0) return false
    return true;
}
//1


const createBook = async function (req, res) {
    try {
        const bookBody = req.body
        if(Object.keys(bookBody) == 0) {
            return res.status(400).send({status: false, message: 'bookDetails must be provided'})
        }

        const { title, excerpt, userId, ISBN, category, subcategory, reviews, releasedAt } = bookBody
        
         //----------------------------------------------------------------------------------------titleValidation
        if(!isValid(title)) {
            return res.status(400).send({status: false, message: 'title is required'})
        }

         let duplicateTitle = await bookModel.findOne({title:title})
         
         if(duplicateTitle) {
            return res.status(400).send({status: false, message: 'title alredy exists'})
        }
         
         //----------------------------------------------------------------------------------------excerptValidation
        if(!isValid(excerpt)) {
            return res.status(400).send({status: false, message: 'excerpt is required'})
        }
        
        //----------------------------------------------------------------------------------------userIdValidation
        if(!isValid(userId)) {
            return res.status(400).send({status: false, message: 'userId is required'})
        }

        const userNotInDB = await userModel.findById(userId) 

        if(!userNotInDB) {
            return res.status(400).send({status:false, msg: `${userId} not in DB `})
        }
        
        //----------------------------------------------------------------------------------------ISBNValidation
        if(!isValid(ISBN)) {
            return res.status(400).send({status: false, message: 'ISBN is required'})
        }

        if (!(/^\+?([1-9]{3})\)?[-. ]?([0-9]{10})$/.test(ISBN))) {
          return res.status(400).send({ status: false, message: 'please provide valid ISBN' })
        }
        
        let duplicateISBN = await bookModel.findOne({ISBN:ISBN})
         
         if(duplicateISBN) {
            return res.status(400).send({status: false, message: 'ISBN alredy exists'})
        }

        //----------------------------------------------------------------------------------------categoryValidation
        if(!isValid(category)) {
            return res.status(400).send({status: false, message: 'category is required'})
        }
        //----------------------------------------------------------------------------------------subcategoryValidation
        if(!isValid(subcategory)) {
            return res.status(400).send({status: false, message: 'subcategory is required'})
        }
        //----------------------------------------------------------------------------------------reviewsValidation
        // if(!isValid(reviews)) {
        //     return res.status(400).send({status: false, message: 'reviews is required'})
        // }
        //----------------------------------------------------------------------------------------releasedAtValidation
        if(!isValid(releasedAt)) {
            return res.status(400).send({status: false, message: 'releasedAt is required'})
        }

        if(!(/^((?:19|20)[0-9][0-9])-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])/.test(bookBody.releasedAt))) {
            return res.status(400).send({status: false, message: 'Invalid date format'})
        }
          
        const reqData = { title, excerpt, userId, ISBN, category, subcategory, reviews, releasedAt:moment(releasedAt) }



        //---------------------------------------------------------------------------------------------bookCreation
        const newBook = await bookModel.create(reqData)
            return res.status(201).send({ status:true, data:newBook, message: "book created successfully"})

    }
    catch(error) {
        return res.status(500).send({status: false, error: error.message})
    }
}

//2


const getBooks=async function(req,res){

    try{
         const queryParams=req.query
        
            const book = await bookModel.find({$and:[queryParams,{isDeleted:false}]}).select({ "_id": 1, "title": 1, "excerpt": 1, "userId": 1 ,"category":1,"releasedAt":1,"reviews":1 }).sort({"title":1})
	          
            if (book.length > 0) {
              res.status(200).send({ status: true,count: book.length,message:'Books list', data: book })
            }
            else {
              res.status(404).send({ msg: "book not found" })
            }
          
    }catch(error){
        res.status(500).send({status:true,message:error.message})
    }

}
//3
//------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*### GET /books/:bookId
- Returns a book with complete details including reviews. Reviews array would be in the form of Array. Response example [here](#book-details-response)
- Return the HTTP status 200 if any documents are found. The response structure should be like [this](#successful-response-structure) 
- If the book has no reviews then the response body should include book detail as shown [here](#book-details-response-no-reviews) and an empty array for reviewsData.
- If no documents are found then return an HTTP status 404 with a response like [this](#error-response-structure)*/ 
 const getBookById = async function (req, res) {
    try {
        const bookId = req.params.bookId
       
        if (!(/^[0-9a-fA-F]{24}$/.test(bookId))) {
            return res.status(400).send({ status: false, message: 'please provide valid bookId' })
          }
        const findBook = await bookModel.findById({ _id: bookId,  isDeleted: false})
        console.log(findBook)

        if (!findBook) {
          return res.status(404).send({ status: false, message: 'book not found' })
        }
    
        const review = await reviewModel.find({ bookId: bookId, isDeleted: false }).select({ _id: 1, bookId: 1, reviewedBy: 1, reviewedAt: 1, rating: 1, review: 1 })
    
        return res.status(200).send({ status: true, message: "Books List", data: { ...findBook.toObject(), reviewsData: review } })
      }
    
    catch(error) {
        return res.status(500).send({status: false, error: error.message})
    }
}


//4
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*### PUT /books/:bookId
- Update a book by changing its
  - title
  - excerpt
  - release date
  - ISBN
- Make sure the unique constraints are not violated when making the update
- Check if the bookId exists (must have isDeleted false and is present in collection). If it doesn't, return an HTTP status 404 with a response body like [this](#error-response-structure)
- Return an HTTP status 200 if updated successfully with a body like [this](#successful-response-structure) 
- Also make sure in the response you return the updated book document.*/

const updateBook = async function (req, res) {
  try {
    const bookId = req.params.bookId

    if (!(/^[0-9a-fA-F]{24}$/.test(bookId))) {
      res.status(400).send({ status: false, message: 'please provide valid bookId' })
      return
    }

    const book = await bookModel.findById({ _id: bookId, isDeleted: false })
    console.log(book)

    if(!(book)) {
      res.status(404).send({ status: false, message: "No data found" })
      return
    }

    if(Object.keys(req.body) == 0) {
      res.status(400).send({status: false, message: 'please provide data for updation'})
      return
  }

    const {title, excerpt, ISBN, releasedAt} = req.body

      if (!isValid(title)) {
        res.status(400).send({ status: false, message: 'please provide title' })
        return
      }

      const duplicateTitle = await bookModel.findOne({title: title})
      if (duplicateTitle) {
        res.status(400).send({ status: false, message: "This title already in use ,please provide another one" })
        return
      }
    
      if (!isValid(excerpt)) {
        res.status(400).send({ status: false, message: 'please provide excerpt' })
        return
      }
  
      if (!isValid(ISBN)) {
        res.status(400).send({ status: false, message: 'please provide ISBN' })
        return
      }
  
      if (!(/^\+?([1-9]{3})\)?[-. ]?([0-9]{10})$/.test(ISBN))) {
        return res.status(400).send({ status: false, message: 'please provide valid ISBN' })
      }

      const duplicateISBN = await bookModel.findOne({ ISBN:ISBN })
      if (duplicateISBN) {
        res.status(400).send({ status: false, message: "This ISBN already in use ,please provide another one" })
        return
      }

      if (!isValid(releasedAt)) {
        res.status(400).send({ status: false, message: 'please provide releasedAt' })
        return
      }
      if (!(/^((?:19|20)[0-9][0-9])-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])/.test(releasedAt))) {
        return res.status(400).send({ status: false, message: 'please provide valid date in format (YYYY-MM-DD)' })
      }

      const updateData = {title, excerpt, ISBN, releasedAt: moment(releasedAt)}
    
    const updatedBook = await bookModel.findOneAndUpdate({ _id: bookId },{...updateData}, { new: true })

    return res.status(200).send({ status: true, message: "Book updated successfully", data: updatedBook })
  }
  catch (err) {
    console.log(err)
    res.status(500).send({ status: false, msg: err.message })
  }
}
  
// 5
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------------
/*### DELETE /books/:bookId
- Check if the bookId exists and is not deleted. If it does, mark it deleted and return an HTTP status 200 with a response body with status and message.
- If the book document doesn't exist then return an HTTP status of 404 with a body like [this](#error-response-structure)*/
const deleteBookById = async function (req, res) {
    try {

      const bookId = req.params.bookId

      if (!(/^[0-9a-fA-F]{24}$/.test(bookId))) {
        return res.status(400).send({ status: false, message: 'please provide valid bookId' })
      }
   
      const book = await bookModel.findOne({ _id: bookId })
    
      if (!book) {
        res.status(404).send({ status: false, message: 'bookId not found' })
        return
      }
   
      if (book.isDeleted == true) {
        res.status(400).send({ status: false, message: "Book is already deleted" })
        return
      }
  
      const deletedBook = await bookModel.findOneAndUpdate({ _id: bookId }, { $set: { isDeleted: true, deletedAt: new Date() } })
  
      res.status(200).send({ status: true, message: "Success" ,message: "Book deleted successfully" })
      return
    }
    catch (err) {
      console.log(err)
      res.status(500).send({ status: false, msg: err.message })
    }
  }

module.exports.createBook = createBook
module.exports.getBooks = getBooks
module.exports.getBookById = getBookById
module.exports.updateBook = updateBook
module.exports.deleteBookById = deleteBookById

















